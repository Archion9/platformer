#include "player.h"

float velocity = 0.0f;

bool AABB(Rectangle a, Rectangle b);

Player::Player(Vector2 position, float speed)  
{
    this->position = position;
    this->speed = speed;
    this->hitbox = { position.x, position.y, 50.0f, 50.0f }; 
}

void Player::Update(Camera2D& camera, World& world) {
    
    float deltaTime = GetFrameTime();

   
    float acceleration = GRAVITY;
    velocity += acceleration * deltaTime;

    for (int i = 0; i < world.width; i++)
    {
        for (int j = 0; j < world.height; j++)
        {
            if (AABB(this->hitbox, (Rectangle){j*50,i*50,50,50}) && world.tileMap[i][j] == World::SOLID)
            {
                velocity = 0.0f;
            }
        }
    }
        
    if (IsKeyPressed(KEY_SPACE) && velocity == 0.0f)
    {
        velocity = -10.0f;
    }
    this->position.y += velocity;

    if (IsKeyDown(KEY_RIGHT)) {
        position.x += speed * deltaTime;
        camera.target.x += speed * deltaTime;
    }
    if (IsKeyDown(KEY_LEFT)) {
        position.x -= speed * deltaTime;
        camera.target.x -= speed * deltaTime;
    }
    
    // Update hitbox position
    hitbox.x = position.x;
    hitbox.y = position.y;
}

void Player::Draw() {
    DrawRectangleRec(hitbox, RED);
}

bool AABB(Rectangle a, Rectangle b) {
    return (a.x < b.x + b.width &&
            a.x + a.width > b.x &&
            a.y < b.y + b.height &&
            a.y + a.height > b.y);
}
