#ifndef INCLUDE_H
#define INCLUDE_H

#include <vector>
#include "../raylib/include/raylib.h"
#include <iostream>

#define GRAVITY 9.81f


#endif // INCLUDE_H
